import time
from collections import deque

class SudokuCSP:

    def __init__(self, puzzle):

        self.variables = [
            (r, c)
            for r in range(9)
            for c in range(9)
        ]

        self.domains = {}

        for r, c in self.variables:

            value = int(puzzle[r * 9 + c])

            if value == 0:
                self.domains[(r, c)] = set(range(1, 10))
            else:
                self.domains[(r, c)] = {value}

        self.neighbors = {
            var: self.get_neighbors(var)
            for var in self.variables
        }

        self.nodes_expanded = 0
        self.backtracks = 0

    def get_neighbors(self, var):

        r, c = var
        neighbors = set()


        for i in range(9):

            if i != c:
                neighbors.add((r, i))

            if i != r:
                neighbors.add((i, c))

        br = (r // 3) * 3
        bc = (c // 3) * 3

        for i in range(br, br + 3):

            for j in range(bc, bc + 3):

                if (i, j) != var:
                    neighbors.add((i, j))

        return neighbors

    def is_consistent(self, var, value, assignment):

        for neighbor in self.neighbors[var]:

            if neighbor in assignment:

                if assignment[neighbor] == value:
                    return False

        return True


    def revise(self, xi, xj):

        removed = set()

        for x in self.domains[xi]:

            supported = False

            for y in self.domains[xj]:

                if x != y:
                    supported = True
                    break

            if not supported:
                removed.add(x)

        if removed:

            self.domains[xi] -= removed
            return True


        return False

    def ac3(self):

        queue = deque(
            (xi, xj)
            for xi in self.variables
            for xj in self.neighbors[xi]
        )


        while queue:

            xi, xj = queue.popleft()


            if self.revise(xi, xj):

                if len(self.domains[xi]) == 0:
                    return False


                for xk in self.neighbors[xi]:

                    if xk != xj:

                        queue.append(
                            (xk, xi)
                        )
        return True


    def select_variable(self, assignment, use_mrv):

        unassigned = [
            v for v in self.variables
            if v not in assignment
        ]


        if not use_mrv:

            return unassigned[0]


        return min(
            unassigned,
            key=lambda x: len(self.domains[x])
        )


    def forward_check(self, var, value):

        removed = {}


        for neighbor in self.neighbors[var]:

            if value in self.domains[neighbor]:

                self.domains[neighbor].remove(value)


                if neighbor not in removed:

                    removed[neighbor] = set()


                removed[neighbor].add(value)


                if len(self.domains[neighbor]) == 0:

                    return False, removed

        return True, removed

    def restore(self, removed):

        for var, values in removed.items():

            self.domains[var].update(values)

    def backtrack(self, assignment, use_mrv):

        self.nodes_expanded += 1


        if len(assignment) == 81:

            return assignment

        var = self.select_variable(
            assignment,
            use_mrv
        )

        for value in list(self.domains[var]):

            if self.is_consistent(
                var,
                value,
                assignment
            ):

                assignment[var] = value
                success, removed = self.forward_check(
                    var,
                    value
                )

                if success:

                    result = self.backtrack(
                        assignment,
                        use_mrv
                    )

                    if result:

                        return result
                    
                self.restore(removed)

                del assignment[var]

        self.backtracks += 1

        return None

def solve_puzzle(puzzle, use_mrv):

    csp = SudokuCSP(puzzle)

    start = time.time()

    if not csp.ac3():

        return None
    
    solution = csp.backtrack(
        {},
        use_mrv
    )
    if solution:


        solved = ""
        for r in range(9):

            for c in range(9):

                solved += str(
                    solution[(r,c)]
                )
        return {

            "solution": solved,

            "time": time.time()-start,

            "nodes": csp.nodes_expanded,

            "backtracks": csp.backtracks

        }
    return None

def read_puzzles():

    with open("puzzles.txt") as file:

        return [

            line.strip()

            for line in file

            if len(line.strip()) == 81

        ]


def write_solutions(solutions):

    with open("solutions.txt","w") as file:

        for solution in solutions:

            file.write(solution+"\n")

def find_hardest_puzzle(puzzles):

    hardest = None

    max_nodes = -1

    print("\nFinding hardest puzzle...")


    for i, puzzle in enumerate(puzzles):


        result = solve_puzzle(
            puzzle,
            True
        )

        print(
            "Puzzle",
            i+1,
            "Nodes:",
            result["nodes"]
        )

        if result["nodes"] > max_nodes:

            max_nodes = result["nodes"]

            hardest = puzzle

    print(
        "Hardest puzzle selected. Nodes:",
        max_nodes
    )

    return hardest

def ablation_test(puzzle):

    print(
        "\n========== ABLATION STUDY =========="
    )

    for name, mrv in [

        ("Without MRV", False),

        ("With MRV", True)

    ]:

        print("\nRunning:", name)
        result = solve_puzzle(
            puzzle,
            mrv
        )
        print(
            "Time:",
            result["time"]
        )
        print(
            "Nodes:",
            result["nodes"]
        )
        print(
            "Backtracks:",
            result["backtracks"]
        )

def main():

    puzzles = read_puzzles()
    solutions = []
    for puzzle in puzzles:

        result = solve_puzzle(
            puzzle,
            True
        )
        if result:

            solutions.append(
                result["solution"]
            )

    write_solutions(
        solutions
    )

    print(
        "solutions.txt generated successfully"
    )
    hardest = find_hardest_puzzle(
        puzzles
    )

    ablation_test(
        hardest
    )

if __name__ == "__main__":

    main()       